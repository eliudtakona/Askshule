// ── School Configuration ─────────────────────────────────────────────────
// Edit this file to customise SMARTshule for each school deployment.

export const SCHOOL = {
  name:     'Greenvalley Academy Narok',
  tagline:  'Excellence. Character. Future.',
  location: 'Karen, Nairobi',
  phone:    '+254 700 123 456',
  email:    'admissions@greenvalleyacademy.ac.ke',
  website:  'www.askshule.com',
  grades:   'PP1 – Grade 12 (CBC)',
  mapLink:  'https://maps.google.com/?q=Karen+Nairobi',
}

export const FEE_DATA = [
  { grade:'PP1 – PP2',           term:'KES 28,500', year:'KES 85,500'  },
  { grade:'Grade 1 – 3',         term:'KES 32,000', year:'KES 96,000'  },
  { grade:'Grade 4 – 6',         term:'KES 36,000', year:'KES 108,000' },
  { grade:'Grade 7 – 9 (JSS)',   term:'KES 42,000', year:'KES 126,000' },
  { grade:'Grade 10 – 12 (SSS)', term:'KES 48,000', year:'KES 144,000' },
]

export const BUS_ROUTES = [
  { id:'A', name:'Town CBD / London / Majengo', fee:'KES 5,500', pickup:'6:15am', dropoff:'4:10pm',
    stops:['Town CBD Stage','London Estate','Majengo','Greenvalley Academy Narok'], seats:5, color:'#1B5E20' },
  { id:'B', name:'Milimani / Korea / Cereals',  fee:'KES 5,500', pickup:'6:20am', dropoff:'4:15pm',
    stops:['Milimani Estate','Korea Estate','Cereals Area','Greenvalley Academy Narok'], seats:4, color:'#E65100' },
  { id:'C', name:'Adams / Waterhole / Olpopong',fee:'KES 6,000', pickup:'6:10am', dropoff:'4:20pm',
    stops:['Adams Estate','Waterhole','Olpopong','Greenvalley Academy Narok'], seats:6, color:'#1A237E' },
  { id:'D', name:'Total / Mwamba / Kamoja',     fee:'KES 5,500', pickup:'6:25am', dropoff:'4:25pm',
    stops:['Total Petrol Station','Mwamba Area','Kamoja','Greenvalley Academy Narok'], seats:3, color:'#880E4F' },
  { id:'E', name:'University / Utawala / Lopito',fee:'KES 6,000', pickup:'6:05am', dropoff:'4:30pm',
    stops:['University Area','Utawala','Lopito','Greenvalley Academy Narok'], seats:7, color:'#4A148C' },
]

export const TERM_DATES = [
  { term:'Term 1 · 2026', open:'Mon, 5 Jan 2026',
    midterm:'Fri, 13 Feb – Mon, 23 Feb 2026', close:'Fri, 3 Apr 2026', color:'#128C7E' },
  { term:'Term 2 · 2026', open:'Mon, 27 Apr 2026',
    midterm:'Fri, 12 Jun – Mon, 22 Jun 2026', close:'Fri, 31 Jul 2026', color:'#1565C0' },
  { term:'Term 3 · 2026', open:'Mon, 24 Aug 2026',
    midterm:'Fri, 2 Oct – Mon, 12 Oct 2026',  close:'Fri, 6 Nov 2026',  color:'#6A1B9A' },
]
