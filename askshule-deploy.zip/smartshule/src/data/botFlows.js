// ── Bot Conversation Flows ────────────────────────────────────────────────
// Each key maps to a bot response. 'type' triggers a rich UI card.
// Add new flows here and reference them in options[].id

export const MENU_ITEMS = [
  { id:'fees',       icon:'💰', label:'Fee Structure'           },
  { id:'admission',  icon:'📋', label:'Admission Process'       },
  { id:'visit',      icon:'🏫', label:'Book a School Visit'     },
  { id:'transport',  icon:'🚌', label:'Transport & Boarding'    },
  { id:'curriculum', icon:'📚', label:'Curriculum & Grades'     },
  { id:'contact',    icon:'📍', label:'Location & Contacts'     },
  { id:'apply',      icon:'✍️', label:'Apply Now'               },
  { id:'human',      icon:'👤', label:'Talk to Admissions Officer'},
]

export const BOT_FLOWS = {
  welcome: {
    messages: [
      "👋 *Habari!* Welcome to *Greenvalley Academy Narok* admissions. I'm SMARTshule, your digital admissions guide.",
      "I can help you with fees, admission process, school visits, transport, and more.\n\nWhat would you like to know today? 👇",
    ],
    options: MENU_ITEMS,
  },
  fees: {
    messages: ["💰 *Fee Structure — 2025/2026 Academic Year*\n\nHere's a breakdown of our current fees:"],
    type: 'fees_table',
    followup: "Would you like to know about payment plans or bursaries? 🎓",
    options: [
      { id:'payment_plan', icon:'📅', label:'Payment Plans'     },
      { id:'bursary',      icon:'🎓', label:'Bursaries?'        },
      { id:'apply',        icon:'✍️', label:'Apply Now'         },
      { id:'menu',         icon:'🔙', label:'Back to Menu'      },
    ],
  },
  admission: {
    messages: ["📋 *Admission Process — Step by Step*\n\nHere's how joining Greenvalley Academy Narok works:"],
    type: 'steps',
    followup: "Our next intake opens *January 2026*. 🎉",
    options: [
      { id:'apply', icon:'✍️', label:'Start Application' },
      { id:'visit', icon:'🏫', label:'Book a Visit First' },
      { id:'menu',  icon:'🔙', label:'Back to Menu'       },
    ],
  },
  visit: {
    messages: ["🏫 *Book a School Visit*\n\nTours run Mon–Fri 9am–12pm and Sat 9am–11am.\n\nPlease fill in your details below:"],
    type: 'visit_form',
    options: [{ id:'menu', icon:'🔙', label:'Back to Menu' }],
  },
  transport: {
    messages: ["🚌 *Transport & Boarding — 2025/2026*\n\nWe run *5 bus routes* across Narok town and estates. Tap a route to see stops and pickup times 👇"],
    type: 'transport_card',
    followup: "🗓️ Buses run on all school days. See term dates below.",
    options: [
      { id:'term_dates',       icon:'📅', label:'Term Dates'          },
      { id:'boarding_inquiry', icon:'🏠', label:'Boarding Inquiry'    },
      { id:'apply',            icon:'✍️', label:'Register Transport'  },
      { id:'menu',             icon:'🔙', label:'Back to Menu'        },
    ],
  },
  term_dates: {
    messages: ["📅 *Academic Calendar 2025/2026*\n\nOpening, midterm, and closing dates for all three terms:"],
    type: 'term_dates_card',
    followup: "📌 Transport runs on all school days.",
    options: [
      { id:'transport', icon:'🚌', label:'Back to Transport' },
      { id:'menu',      icon:'🔙', label:'Back to Menu'      },
    ],
  },
  curriculum: {
    messages: ["📚 *Curriculum & Grades*\n\nWe follow the Kenyan CBC:\n\n🟢 *Pre-Primary:* PP1 & PP2\n🟡 *Lower Primary:* Grade 1 – 3\n🟠 *Upper Primary:* Grade 4 – 6\n🔵 *Junior Secondary:* Grade 7 – 9\n🟣 *Senior Secondary:* Grade 10 – 12\n\n*Extra-Curricular:* Robotics · Drama · Football · Swimming · Chess · Music"],
    options: [
      { id:'fees',  icon:'💰', label:'View Fees by Grade' },
      { id:'apply', icon:'✍️', label:'Apply Now'          },
      { id:'menu',  icon:'🔙', label:'Back to Menu'       },
    ],
  },
  contact: {
    messages: ["📍 *Location & Contacts*\n\n🏫 Karen Road, off Ngong Road, Karen, Nairobi\n📞 +254 700 123 456\n📧 admissions@greenvalleyacademy.ac.ke\n\n⏰ Mon–Fri: 7:30am–5pm · Sat: 8am–1pm"],
    type: 'map',
    options: [
      { id:'visit', icon:'🏫', label:'Book a Visit'   },
      { id:'human', icon:'👤', label:'Call an Officer' },
      { id:'menu',  icon:'🔙', label:'Back to Menu'   },
    ],
  },
  apply: {
    messages: ["✍️ *Admission Application Form*\n\nLet's collect a few details to get started:"],
    type: 'application_form',
    options: [],
  },
  human: {
    messages: ["👤 *Talk to an Admissions Officer*\n\n📞 *+254 700 123 456*\n⏰ Mon–Fri 8am–5pm · Sat 8am–12pm\n\nOr leave your number and we'll call you back within 2 hours:"],
    type: 'callback_form',
    options: [{ id:'menu', icon:'🔙', label:'Back to Menu' }],
  },
  payment_plan: {
    messages: ["📅 *Payment Plans*\n\n✅ *Full Term:* 5% discount if paid week 1\n✅ *Monthly:* 3 instalments per term\n✅ *Annual:* 8% discount paid upfront\n\n🏦 Equity Bank · A/C: 0123456789 · Greenvalley Academy Narok Ltd"],
    options: [
      { id:'apply', icon:'✍️', label:'Apply Now'      },
      { id:'menu',  icon:'🔙', label:'Back to Menu'   },
    ],
  },
  bursary: {
    messages: ["🎓 *Bursaries & Scholarships*\n\n🌟 Academic Excellence: 10–30% reduction\n🤝 Sibling Discount: 5% 2nd child, 8% 3rd+\n🏆 Sports/Arts: up to 15%\n📝 Need-Based: apply with documents\n\nDeadline: *30 November 2025*"],
    options: [
      { id:'apply', icon:'✍️', label:'Apply + Bursary'    },
      { id:'human', icon:'👤', label:'Speak to Officer'   },
      { id:'menu',  icon:'🔙', label:'Back to Menu'       },
    ],
  },
  boarding_inquiry: {
    messages: ["🏠 *Boarding (Grade 7–12)*\n\n🛏️ *Full Boarding:* KES 35,000/term\n• 3 meals + laundry + supervised prep\n\n🌙 *Half Boarding:* KES 22,000/term\n• Sun evening–Fri afternoon\n\n⚠️ Only *12 places* left for Jan 2026!"],
    options: [
      { id:'apply', icon:'✍️', label:'Apply for Boarding' },
      { id:'human', icon:'👤', label:'Talk to Matron'     },
      { id:'menu',  icon:'🔙', label:'Back to Menu'       },
    ],
  },
  menu: { redirect: 'welcome' },
}
