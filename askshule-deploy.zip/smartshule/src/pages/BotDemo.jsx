// Re-exports the main bot demo (same as your existing smartshule artifact)
// Drop your full smartshule.jsx component logic here.
// For now this is a placeholder that imports from components.

export { default } from '../components/ChatDemo'
