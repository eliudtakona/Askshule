export { default } from '../components/SetupPanel'
