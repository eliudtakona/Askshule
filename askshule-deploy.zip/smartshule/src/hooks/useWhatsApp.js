// ── useWhatsApp Hook ─────────────────────────────────────────────────────
// Sends real WhatsApp messages via Meta Cloud API.
// In development (no token), messages are logged to console only.
// In production, set VITE_WHATSAPP_TOKEN in your .env

import { useState, useCallback } from 'react'

const API_BASE = '/api'

export function useWhatsApp() {
  const [sending, setSending] = useState(false)
  const [error,   setError  ] = useState(null)

  // Send a text message to a phone number
  const sendMessage = useCallback(async (to, message) => {
    setSending(true)
    setError(null)
    try {
      const res = await fetch(`${API_BASE}/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to, message }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      return await res.json()
    } catch (err) {
      setError(err.message)
      console.error('[useWhatsApp] sendMessage failed:', err)
    } finally {
      setSending(false)
    }
  }, [])

  // Save a lead to the backend (triggers admin notification)
  const saveLead = useCallback(async (leadData) => {
    try {
      const res = await fetch(`${API_BASE}/leads`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadData),
      })
      return await res.json()
    } catch (err) {
      console.error('[useWhatsApp] saveLead failed:', err)
    }
  }, [])

  return { sendMessage, saveLead, sending, error }
}
